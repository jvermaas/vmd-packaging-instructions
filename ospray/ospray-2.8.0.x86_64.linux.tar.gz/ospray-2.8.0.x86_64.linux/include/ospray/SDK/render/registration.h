// Copyright 2020 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

namespace ospray {

void registerAllRenderers();
void registerAllMaterials();

} // namespace ospray
