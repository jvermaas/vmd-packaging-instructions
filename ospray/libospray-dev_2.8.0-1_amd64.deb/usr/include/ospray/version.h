// Copyright 2009-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#define OSPRAY_VERSION_MAJOR 2
#define OSPRAY_VERSION_MINOR 8
#define OSPRAY_VERSION_PATCH 0
#define OSPRAY_SOVERSION 2
#define OSPRAY_VERSION_GITHASH "fe4b3806f8626b22defbeda172609aa7c8c74a2e"
#define OSPRAY_VERSION_NOTE " (fe4b3806)"
#define OSPRAY_VERSION "2.8.0"
